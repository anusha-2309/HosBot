#!/bin/bash
sudo apt update && sudo apt upgrade -y
echo "System updated successfully."