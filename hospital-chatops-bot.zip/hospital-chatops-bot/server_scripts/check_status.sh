#!/bin/bash
systemctl is-active nginx