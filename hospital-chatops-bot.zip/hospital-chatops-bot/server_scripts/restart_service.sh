#!/bin/bash
sudo systemctl restart nginx
echo "Service nginx restarted successfully."