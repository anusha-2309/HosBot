# Hospital ChatOps Bot

A simple Slack ChatOps bot that allows hospital IT admins to manage servers through Slack commands!

## Features:
- Check server status (`/status`)
- Restart services (`/restart`)
- Update system packages (`/update`)

## Setup Instructions:
1. Create a Slack App and set up Slash Commands (`/status`, `/restart`, `/update`).
2. Replace `your-slack-verification-token` in `app.py` with your actual Slack token.
3. Install dependencies:
    ```
    pip install -r requirements.txt
    ```
4. Run the Flask app:
    ```
    python app.py
    ```
5. (Optional) Use ngrok for local development:
    ```
    ngrok http 3000
    ```

## Technologies Used:
- Python
- Flask
- Slack API
- Bash scripting